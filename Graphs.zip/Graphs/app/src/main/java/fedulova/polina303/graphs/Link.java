package fedulova.polina303.graphs;

public class Link {
    public int a, b;

    public Link(int a, int b)
    {
        this.a = a;
        this.b = b;
    }

}
